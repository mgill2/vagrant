<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
  <a href="browse.php">browse.php</a>
  <a href="about.php">about.php</a>
  <a href="contact.php">contact.php</a>
  <a href="index.php">index.php</a>

<p>
Don Quixote (/ˌdɒn ˈkwɪksət/[1] or /ˌdɒn kiːˈhoʊtiː/; Spanish: [ˈdoŋ kiˈxote] ( listen)), fully titled The Ingenious Gentleman Don Quixote of La Mancha (Spanish: El ingenioso hidalgo don Quijote de la Mancha), is a Spanish novel by Miguel de Cervantes Saavedra. Published in two volumes, in 1605 and 1615, Don Quixote is considered one of the most influential works of literature from the Spanish Golden Age and the entire Spanish literary canon. As a founding work of modern Western literature and one of the earliest canonical novels, it regularly appears high on lists of the greatest works of fiction ever published, such as the Bokklubben World Library collection that cites Don Quixote as authors' choice for the "best literary work ever written".[2]
</p>
        <?php
        echo "hello world";
        ?>
    </body>
</html>
