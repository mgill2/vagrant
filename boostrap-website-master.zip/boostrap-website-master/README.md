# boostrap-website
Sample website that uses Bootstrap Framework for responsive development
